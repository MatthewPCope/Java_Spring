package com.javaoop.zookeeper;

public class Bat extends Mammal {

	public void fly(int times) {
		rareEnergy -= 50 * times;
		System.out.println("Bat is currently airborne \n\n");
	}
	
	public void eatHuman(int times) {
		rareEnergy += 25 * times;
		if(times > 1) {
			System.out.printf("The bat just ate %d humans!  It is definitely satisfied. \n\n", times);
		} else {
			System.out.println("The bat just ate a human!  It is now satisfied. \n\n");
		}
	}
	
	public void attackTown(int amount) {
		rareEnergy -= 100 * amount;
		if(amount > 1) {
			System.out.printf("The bat just attacked %d towns!  Be safe out there!, \n\n", amount);
		} else {
			System.out.println("The bat has attacked a town! \n\n");
		}
	}
}
			
