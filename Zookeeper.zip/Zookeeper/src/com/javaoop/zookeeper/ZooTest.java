package com.javaoop.zookeeper;

public class ZooTest {

	public static void main(String[] args) {
		
		//Gorilla
		
		Gorilla gorilla1 = new Gorilla();
		
		gorilla1.throwSomething(3);
		
		gorilla1.eatBananas(4);
		
		gorilla1.climb();
		
		Mammal.displayEnergy();
		
		
		//Bat
		
		Bat rareBat = new Bat();
		
		
		rareBat.attackTown(3);

		rareBat.eatHuman(5);
		
		rareBat.fly(3);
		
		Mammal.displayRareEnergy();
		
	}

}
