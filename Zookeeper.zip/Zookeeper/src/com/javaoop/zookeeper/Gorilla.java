package com.javaoop.zookeeper;

public class Gorilla extends Mammal {

	public void throwSomething(int times) {
		energy -= 5 * times;
		System.out.printf("The gorilla has thrown something %d times. \n\n", times);
		
	}
	
	public void eatBananas(int amount) {
		energy += 10 * amount;
		if(amount > 1) {
			System.out.printf("The gorilla ate %d bananas and is now satisfied. \n\n", amount);
		} else {
			System.out.printf("The gorilla ate a banana and is now satisfied. \n\n", amount);
		}
		
	}
	
	public void climb() {
		energy -= 10;
		System.out.println("The gorilla has climbed a tree. \n\n");
		
	}

}
