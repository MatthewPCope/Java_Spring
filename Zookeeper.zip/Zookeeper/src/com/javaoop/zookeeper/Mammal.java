package com.javaoop.zookeeper;

public class Mammal {

	public static int energy = 100;
	public static int rareEnergy = 300;
	

	public static int displayEnergy() {
		System.out.println("Current energy = " + energy);
		return energy;
	}
	
	public static int displayRareEnergy() {
		System.out.println("Current energy = " + rareEnergy);
		return rareEnergy;
	}


	
	
	
	
}
