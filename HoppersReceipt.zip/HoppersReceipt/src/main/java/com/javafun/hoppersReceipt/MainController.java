package com.javafun.hoppersReceipt;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class MainController {
    @RequestMapping("/")
    public String index(Model model) {
        
        String name = "Matt Cope";
        String itemName = "Guitar Strings";
        double price = 5.25;
        String description = "Strings for an accoustic guitar";
        String vendor = "Guitar Store & More";
    
        model.addAttribute("name", name);
        model.addAttribute("itemName", itemName);
        model.addAttribute("price", price);
        model.addAttribute("description", description);
        model.addAttribute("vendor", vendor);
    	// Your code here! Add values to the view model to be rendered
    
        return "index.jsp";
    }
    //...
    

	
	
	
	
}
