
public class BankTest {

	public static void main(String[] args) {
		
		BankAccount mattAccount = new BankAccount();
		BankAccount jenAccount = new BankAccount();
		BankAccount harlanAccount = new BankAccount();
		
		
		mattAccount.depositMoney(1000, "checking");
		mattAccount.depositMoney(5000, "savings");
		
		jenAccount.depositMoney(500, "checking");
		jenAccount.depositMoney(1000, "savings");
		
		harlanAccount.depositMoney(100, "checking");
		harlanAccount.depositMoney(500, "savings");
		
		System.out.println(mattAccount.getCheckingBalance());
		System.out.println(mattAccount.getSavingsBalance());
//		
		
		
		mattAccount.withdrawMoney(100, "checking");
		mattAccount.withdrawMoney(300, "savings");
		
		System.out.println(mattAccount.getCheckingBalance());
		System.out.println(mattAccount.getSavingsBalance());
		
		
		mattAccount.withdrawMoney(6000, "savings");
		
		System.out.println(BankAccount.totalMoney);
		System.out.println(BankAccount.accounts);
		
		// Create 3 bank accounts
		// Deposit Test
		// - deposit some money into each bank account's checking or savings account and display the balance each time
		// - each deposit should increase the amount of totalMoney
		// Withdrawal Test
		// - withdraw some money from each bank account's checking or savings account and display the remaining balance
		// - each withdrawal should decrease the amount of totalMoney
		// Static Test (print the number of bank accounts and the totalMoney)
		
		  


	}

}
