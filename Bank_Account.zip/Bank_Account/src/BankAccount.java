
public class BankAccount {
	// MEMBER VARIABLES
		private double checkingBalance;
		private double savingsBalance;
		public static int accounts = 0;
		public static double totalMoney = 0; // refers to the sum of all bank account checking and savings balances
		
		
		//constructor
		
		public BankAccount() {
			BankAccount.accounts += 1;
			this.checkingBalance = 0;
			this.savingsBalance = 0;
		}
		
		public BankAccount(double checkingBalance, double savingsBalance) {
			this.checkingBalance = checkingBalance;
			this.savingsBalance = savingsBalance;
			
		}
		
		//methods
		
		public void depositMoney(double amount, String account) {
			if (account == "checking") {
				this.checkingBalance += amount;
			}
			else {
				this.savingsBalance += amount;
			}
			
			BankAccount.totalMoney += amount;
		}
		
		public void withdrawMoney(double amount, String account) {
			if (account == "checking") {
				if(amount > this.checkingBalance) {
					System.out.println("Insufficient Funds");
					return;
				}
				this.checkingBalance -= amount;
			}
			else {
				if(amount > this.savingsBalance) {
					System.out.println("Insufficient Funds");
					return;
				}
				this.savingsBalance -= amount;
			}
			
			BankAccount.totalMoney -= amount;
		}
		//getters
	
		public double getCheckingBalance() {
			return this.checkingBalance;
		}
	
		public double getSavingsBalance() {
			return this.savingsBalance;
		}
	
		
			
		// CONSTRUCTOR
		// Be sure to increment the number of accounts
		// GETTERS
		// for checking, savings, accounts, and totalMoney
		// METHODS
		// deposit
		// - users should be able to deposit money into their checking or savings account
		// withdraw 
		// - users should be able to withdraw money from their checking or savings account
		// - do not allow them to withdraw money if there are insufficient funds
		// - all deposits and withdrawals should affect totalMoney
		// getBalance
		// - display total balance for checking and savings of a particular bank account
	
		
	
	
	
		
}
	
		
		
		
		
